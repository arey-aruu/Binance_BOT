
# Binance Futures Trading Bot (Testnet)

## Setup
1. Install Python 3.x
2. Install dependencies:
   pip install -r requirements.txt

3. Add your API keys in cli.py

## Run Examples

Market Order:
python cli.py BTCUSDT BUY MARKET 0.01

Limit Order:
python cli.py BTCUSDT SELL LIMIT 0.01 --price 60000

## Logs
Check bot.log file.

## Note on Binance Futures Testnet
Binance Futures Testnet sometimes returns empty responses (`{}`) for order and balance endpoints.
The application handles this gracefully by:
- Logging all requests and responses
- Printing a clear success message to the user
- Instructing the user to verify the order in the Testnet UI (Order History)
