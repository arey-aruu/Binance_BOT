from binance.client import Client

API_KEY = "YOUR_API_KEY"
API_SECRET = "YOUR_SECRET_KEY"

client = Client(API_KEY, API_SECRET)
client.FUTURES_URL = "https://testnet.binancefuture.com"

print(client.futures_account_balance())
