
from bot.client import BinanceClient
from bot.validators import validate_inputs
from bot.logging_config import logger

class OrderService:
    def __init__(self, api_key, api_secret):
        self.client = BinanceClient(api_key, api_secret)

    def execute_order(self, symbol, side, order_type, quantity, price=None):
        validate_inputs(symbol, side, order_type, quantity, price)

    # set margin + leverage
        try:
            self.client.client.futures_change_margin_type(
            symbol=symbol, marginType="ISOLATED"
        )
        except Exception:
            pass  # already set

        self.client.set_leverage(symbol, 10)

        params = {
            "symbol": symbol,
            "side": side,
            "type": order_type,
            "quantity": quantity,
            "newOrderRespType": "RESULT"
        }

        if order_type == "LIMIT":
            params["price"] = price
            params["timeInForce"] = "GTC"

        order = self.client.place_order(**params)

        logger.info(f"Order Request: {params}")
        logger.info(f"Order Response: {order}")

        return order
