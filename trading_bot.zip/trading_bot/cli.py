
import argparse
from bot.orders import OrderService

API_KEY = "9SlhgRn7Vt0EaftamNSfXnbTlv5LcGBDRzZQ4HXF8j5eCFPAjI0uWM8iNGIp5AtO"
API_SECRET = "********"

parser = argparse.ArgumentParser(description="Binance Futures Trading Bot")
parser.add_argument("symbol")
parser.add_argument("side")
parser.add_argument("order_type")
parser.add_argument("quantity", type=float)
parser.add_argument("--price", type=float)

args = parser.parse_args()

service = OrderService(API_KEY, API_SECRET)

order = service.execute_order(
    args.symbol, args.side, args.order_type, args.quantity, args.price
)

print("Order request sent successfully.")

if not order:
    print("Binance Testnet returned empty response (known behavior).")
    print("Please check Order History on Testnet UI.")
else:
    print("Full Order Response:", order)
    print("Order ID:", order.get("orderId"))
    print("Status:", order.get("status"))
    print("Executed Qty:", order.get("executedQty"))
    print("Avg Price:", order.get("avgPrice", "N/A"))

